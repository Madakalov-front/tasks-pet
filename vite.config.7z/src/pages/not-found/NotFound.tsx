export const NotFound = () => {
  return (
    <>
      <div className="container">
        <h1>404 - not found page</h1>
      </div>
    </>
  );
};
