export { CardTask } from "./ui/CardTask";
export type { CardTaskProps } from "./model/type-card-task";
